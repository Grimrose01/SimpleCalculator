﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void computeResultButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(firstNumberTextBox.Text) || string.IsNullOrWhiteSpace(secondNumberTextBox.Text))
            {
                MessageBox.Show("Please enter valid numbers in both fields.");
                return;
            }

            if (!double.TryParse(firstNumberTextBox.Text, out double firstNumber) || !double.TryParse(secondNumberTextBox.Text, out double secondNumber))
            {
                MessageBox.Show("Please enter valid numbers in both fields.");
                return;
            }

            string selectedOperation = operationComboBox.SelectedItem as string;
            if (selectedOperation == null)
            {
                MessageBox.Show("Please select an operation.");
                return;
            }
            int firstno = int.Parse(firstNumberTextBox.Text);
            int secondno = int.Parse(secondNumberTextBox.Text);
            int intTotal;

            intTotal = 0;

            switch (operationComboBox.Text)
            {
                case "+":
                    intTotal = firstno + secondno;
                    break;
                case "-":
                    intTotal = firstno - secondno;
                    break;
                case "*":
                    intTotal = firstno * secondno;
                    break;
                case "/":
                    intTotal = firstno / secondno;
                    break;
            }

            resultTextBox.Text = intTotal.ToString();
        }
    }
    }

